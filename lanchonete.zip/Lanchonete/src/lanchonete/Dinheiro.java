package lanchonete;

public class Dinheiro {
	protected double d;
	
	
//Métodos
	public double acumulador1() { //pedido 100
		return d = d + 9;
		}
	
	public double acumulador2() { //101
		return d = d + 11;
		
		}
	public double acumulador3() { //102 e 103
		return d = d + 12;
		}
	
	public double acumulador4() { //104
		return d = d + 14;
	}
	
	public double acumulador5() {
		return d = d + 17;
	}
	
	public double acumulador6() {
		return d = d + 5;
	}
	
	public double acumulador7() {
		return d = d + 4;
	}
	
	}

